package com.example.clientinfoservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientInfoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientInfoServiceApplication.class, args);
	}

}
