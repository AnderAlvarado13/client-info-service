package com.example.clientinfoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientInfoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
